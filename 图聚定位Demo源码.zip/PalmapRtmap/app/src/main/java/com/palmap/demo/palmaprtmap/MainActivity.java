package com.palmap.demo.palmaprtmap;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.palmaplus.nagrand.position.ble.BeaconLocationManager;
import com.rtm.frm.data.Location;
import com.rtm.frm.map.CompassLayer;
import com.rtm.frm.map.LocationLayer;
import com.rtm.frm.map.MapView;
import com.rtm.frm.map.POILayer;
import com.rtm.frm.map.TapPOILayer;
import com.rtm.frm.map.XunluMap;

import java.util.Arrays;
import java.util.List;
import java.util.Timer;

public class MainActivity  extends Activity{
  private MapView mMapView;// 地图view
  private CompassLayer mCompassLayer;// 指南针图层
  private LocationLayer mLocationLayer;
  private POILayer mPoiLayer;// 搜索结果POI图层
  private TapPOILayer mTapLayer;// 点击poi图层
  Location location;
  long locationFloorId;
  Timer timer;
  static int debug = 92;

  String buildingId;
  String floorId = "F1";

  private TextView tv_floor;
  private ListView mFloorListView;
  private List<String> mFloorListData;
  private int mFloorIndex; // 当前楼层索引
  protected FloorListAdapter mFloorListAdapter = null;
  private ScaleAnimation mEnterAnimation;
  private ScaleAnimation mExitAnimation;

  private BeaconLocationManager pm;
//  com.palmaplus.nagrand.view.MapView mapViewPalmap;
//  LocationMark locationMark;
  private RelativeLayout mOverlayContainer;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    initView();

    copyMap();

    initPalmap();

    initRtmap();

//    initLocationMark();
  }

  private void copyMap(){
    // copy字体文件和lur配置文件
    if (FileUtils.checkoutSDCard()) {
      FileUtils.copyDirToSDCardFromAsserts(this, Constant.RMAP_NAME, "data");
    } else {
      Toast.makeText(this,"未找到SDCard",Toast.LENGTH_LONG).show();
    }
  }

  private void initView() {
    mFloorListView = (ListView) findViewById(R.id.map_list_view);

//    mapViewPalmap = (com.palmaplus.nagrand.view.MapView)findViewById(R.id.mapview);
//    mapViewPalmap.setOnSingleTapListener(new OnSingleTapListener() {
//      @Override
//      public void onSingleTap(com.palmaplus.nagrand.view.MapView mapView, float v, float v1) {
//        Types.Point point = mapViewPalmap.converToWorldCoordinate(v,v1);
//        locationMark = new LocationMark(MainActivity.this,mapViewPalmap);
//        locationMark.init(new double[]{point.x,point.y});
//        mapViewPalmap.addOverlay(locationMark); //将这个覆盖物添加到MapView中
//
//        location = new Location((float) x,(float) y);
//        location.setFloor(floorId);
////                mMapView.setMyCurrentLocation(location, false);
//        mMapView.setMyCurrentLocation(location, false);
//
//      }
//    });
    tv_floor = (TextView) findViewById(R.id.map_floor_name);
    tv_floor.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {

        if (mFloorListView.getVisibility() == View.GONE) { // 切换状态
          showFloorListView();
        } else {
          hideFloorListView();
        }
      }
    });

  }
  private void initPalmap() {
      initLocate();
  }
  private void initLocate(){

    pm = new BeaconLocationManager( // 蓝牙定位管理对象
        this,
        Constant.MAP_ID, //输入mapId，用于下载特征数据库
        Constant.APP_KEY //输入AppKey
    );

    pm.setOnLocationChangeListener(
        new BeaconLocationManager.OnLocationChangeListener() {
          @Override
          public void onLocationChange(BeaconLocationManager.LocationStatus status, com.palmaplus.nagrand.position.ble.utils.Location oldLocation, com.palmaplus.nagrand.position.ble.utils.Location newLocation) {


            switch (status) {
              case START:
                break;
              case STOP:
                break;
              case CLOSE:
                break;
              case MOVE:

                double x = newLocation==null ? 0 : newLocation.getX();
                double y = newLocation==null ? 0 : newLocation.getY();

                //获取楼层
                locationFloorId = newLocation.getFloorId();

                if (Constant.isDebug){
                      if (debug++>10) {
                        debug=0;
                        Toast.makeText(MainActivity.this, "x=" + x + " y=" + y + "\nfloor=" + locationFloorId, Toast.LENGTH_SHORT).show();
                      }
                }
                location = new Location((float) x,(float) y);
                location.setFloor(floorId);
                mMapView.setCurrentBuildId(buildingId);
                mMapView.setMyCurrentLocation(location, false);

              case ENTER:
                break;
              case OUT:
                break;
              case HEART_BEAT:
                break;
              case ERROR:
                break;
            }
          }
        });


//    timer = new Timer();
//    timer.schedule(new TimerTask(){
//      public void run(){
//        location = new Location((float) debug++,(float) debug-150);
//        location.setFloor(floorId);
//        mMapView.setCurrentBuildId(buildingId);
//        mMapView.setMyCurrentLocation(location, false);
//      }
//    }, 1000,3000);
    pm.start();

  }

  private void initRtmap(){
    XunluMap.getInstance().setContext(this);
    mMapView = (MapView) findViewById(R.id.map_view);
    initLayers();// 初始化图层
    mFloorListData = Arrays.asList("B1", "B2", "F1","F2","F3","F4","F5");
    loadMap(2);// 打开地图

    mMapView.initScale();// 初始化比例尺
    mMapView.refreshMap();
    initFloorListView();
  }
  public void loadMap(int index){
//    mMapView.clearMapLayer();

    buildingId = (index+1)+"";
    floorId = mFloorListData.get(index).toLowerCase();
    mMapView.setCurrentBuildId(buildingId);
    mMapView.initMapConfig(buildingId, floorId);// 打开地图（建筑物id，楼层id）
    mMapView.redraw=true;
    mMapView.refreshMap();

  }

  /*
 *  初始化楼层列表view
 * */
  private void initFloorListView() {
    mFloorListAdapter = new FloorListAdapter(this, mFloorListData);
    mFloorListView.setAdapter(mFloorListAdapter);
    setListViewBasedOnItem(mFloorListView, 5, true);
    mFloorListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> parent, View view, int position, long id) { // TODO 切换楼层
        if (position != mFloorIndex) { // 不同层, 需要跳转
          hideFloorListView();
          mFloorIndex = position;
          tv_floor.setText(String.valueOf(mFloorListData.get(mFloorIndex)));
          // 切换地图
          loadMap(position);
          mMapView.refreshMap();
        }
      }
    });

    // 创建动画对象
    mEnterAnimation = new ScaleAnimation(1, 1, 0, 1, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 1);
    mEnterAnimation.setDuration(500);
    mExitAnimation = new ScaleAnimation(1, 1, 1, 0, Animation.RELATIVE_TO_SELF, 0, Animation.RELATIVE_TO_SELF, 1);
    mExitAnimation.setDuration(500);
  }
  /*
*  根据item项设置listView宽高
*  @param isMeasuredWidth 是否测量width
* */
  private void setListViewBasedOnItem(ListView listView, int maxLineNum, boolean isMeasuredWidth){
    ListAdapter listAdapter = listView.getAdapter();
    if (listAdapter == null){
      return;
    }

    int totalHeight = 0;
    int maxWidth = 0;
//    int lineNum = maxLineNum > 0 ? maxLineNum : 1; // 至少为1

    View listItem = null;
    Log.e("exp", "listAdapter.getCount() = " + listAdapter.getCount());
    for (int i = 0; i < maxLineNum && i < listAdapter.getCount(); i++){
      listItem = listAdapter.getView(i, null, listView);
      listItem.measure(0, 0);
      totalHeight += listItem.getMeasuredHeight();
      int width = listItem.getMeasuredWidth();
      if (width > maxWidth) maxWidth = width;
    }

//    totalHeight += listView.getDividerHeight() * (lineNum - 1); // 加上分割线高度
    totalHeight += listView.getDividerHeight() * maxLineNum; // 加上分割线高度

    ViewGroup.LayoutParams layoutParams = listView.getLayoutParams();
    layoutParams.height = totalHeight;
    if (isMeasuredWidth){
      layoutParams.width = maxWidth;
    }
    listView.setLayoutParams(layoutParams);

  }
  /**
   * 初始化图层
   */
  private void initLayers() {
    mCompassLayer = new CompassLayer(mMapView);
    mMapView.addMapLayer(mCompassLayer);
    mPoiLayer = new POILayer(mMapView);
//    mPoiLayer.setPoiIcon(BitmapFactory.decodeResource(getResources(),
//        R.drawable.da_marker_red));
    mMapView.addMapLayer(mPoiLayer);
    mTapLayer = new TapPOILayer(mMapView);
    mMapView.addMapLayer(mTapLayer);
    mLocationLayer = new LocationLayer(mMapView);
    mMapView.addMapLayer(mLocationLayer);
    mMapView.refreshMap();
  }

  @Override
  protected void onDestroy() {
    super.onDestroy();
    mMapView.clearMapLayer();
  }

  /*
    *  显示楼层列表
    * */
  private void showFloorListView() {
    mFloorListView.setVisibility(View.VISIBLE);
    mFloorListView.startAnimation(mEnterAnimation);
  }

  /*
  *  隐藏楼层列表
  * */
  private void hideFloorListView() {
    mFloorListView.startAnimation(mExitAnimation);
    mFloorListView.setVisibility(View.GONE);
  }
//  private void initLocationMark(){
//    locationMark = new LocationMark(this, mapViewPalmap);
//
//    mOverlayContainer = (RelativeLayout) findViewById(R.id.map_view_container); //拿到RelativeLayout
//    mapViewPalmap.setOverlayContainer(mOverlayContainer); //然后将它变成覆盖物容器
//    locationMark  = new LocationMark(getApplicationContext(), mapViewPalmap); //创建一个覆盖物
//  }
}
